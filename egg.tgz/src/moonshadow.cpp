// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Project moonshadow"); }
int main(){
  announce();
  return lionss_run_workload("moonshadow");
}
