// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Fit vega surface\n", stdout);
  return lionss_run_workload("VegaSurface");
}
