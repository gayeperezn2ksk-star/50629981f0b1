// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Promote GC objects\n", stdout);
  return lionss_run_workload("gcTier");
}
